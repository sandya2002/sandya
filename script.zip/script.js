// Fetch cart data from JSON API and render cart items
async function fetchCartData() {
    const response = await fetch('https://api.example.com/cart');
    const cartData = await response.json();
    displayCartItems(cartData.items);
}

function displayCartItems(items) {
    const cartItemsContainer = document.querySelector('.cart-items');
    cartItemsContainer.innerHTML = ''; // Clear previous items

    let subtotal = 0;

    items.forEach(item => {
        const itemSubtotal = item.price * item.quantity;
        subtotal += itemSubtotal;

        const itemElement = document.createElement('div');
        itemElement.classList.add('cart-item');
        itemElement.innerHTML = `
            <img src="${item.image}" alt="${item.title}" />
            <div>${item.title}</div>
            <div>$${item.price.toFixed(2)}</div>
            <input type="number" value="${item.quantity}" min="1" onchange="updateQuantity(${item.id}, this.value)" />
            <div>$${itemSubtotal.toFixed(2)}</div>
            <button onclick="removeItem(${item.id})">🗑️</button>
        `;
        cartItemsContainer.appendChild(itemElement);
    });

    document.getElementById('subtotal').textContent = subtotal.toFixed(2);
    document.getElementById('total').textContent = subtotal.toFixed(2); // Update total
}

function updateQuantity(id, quantity) {
    // Logic to update quantity in the cart
    fetchCartData(); // Re-fetch data for simplicity
}

function removeItem(id) {
    // Logic to remove item from cart
    fetchCartData(); // Re-fetch data for simplicity
}

document.getElementById('checkout-btn').addEventListener('click', () => {
    // Logic to handle checkout
    alert('Proceeding to checkout...');
});

// Initial fetch on page load
window.onload = fetchCartData;
